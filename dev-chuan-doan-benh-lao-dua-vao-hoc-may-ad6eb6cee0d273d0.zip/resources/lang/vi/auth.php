<?php

return [
    'failed'   => 'Không có dữ liệu nào phù hợp.',
    'password' => 'Sai mật khẩu hoặc tài khoản.',
    'throttle' => 'Quá nhiều lần đăng nhập sau. Vui lòng thử lại sau :seconds giây.',
];
