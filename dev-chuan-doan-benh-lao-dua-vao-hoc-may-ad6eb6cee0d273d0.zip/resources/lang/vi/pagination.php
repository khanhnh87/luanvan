<?php

return [
    'previous' => '&laquo; Lùi',
    'next'     => 'Tiếp &raquo;',
];
