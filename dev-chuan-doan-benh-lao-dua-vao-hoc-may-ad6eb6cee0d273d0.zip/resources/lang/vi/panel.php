<?php

return [
    'site_title' => 'Chuẩn đoán bệnh lao dựa vào học máy',
];
