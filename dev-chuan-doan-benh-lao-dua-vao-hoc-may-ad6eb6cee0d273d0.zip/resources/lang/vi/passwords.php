<?php

return [
    'password' => 'Mật khẩu phải có ít nhất sáu ký tự và khớp với xác nhận.',
    'reset'    => 'Mật khẩu của bạn đã được thiết lập lại!',
    'sent'     => 'Chúng tôi đã gửi qua e-mail liên kết đặt lại mật khẩu của bạn!',
    'token'    => 'Mã thông báo đặt lại mật khẩu này không hợp lệ.',
    'user'     => 'Chúng tôi không thể tìm thấy người dùng có địa chỉ e-mail đó.',
    'updated'  => 'Mật khẩu của bạn đã được thay đổi!',
];
